



function getClientUrl() {  
 var context;  
 // GetGlobalContext defined by including reference to   
 // ClientGlobalContext.js.aspx in the HTML page.  
 if (typeof GetGlobalContext != "undefined") {  
  context = GetGlobalContext();  
 } else {  
  if (typeof Xrm != "undefined") {  
   // Xrm.Page.context defined within the Xrm.Page object model for form scripts.  
   context = Xrm.Page.context;  
  } else {  
   throw new Error("Context is not available.");  
  }  
 }  
 return context.getClientUrl();  
};

 function OnLoad()
{
    console.log("Onload");
    
    DisplayOdometer("133000", "Label");
  
   // gettingQuickStatisticsRecords();

    
}
function gettingQuickStatisticsRecords ()
{
    Xrm.WebApi.retrieveMultipleRecords("account", "?$select=name&$top=3").then(
        function success(result) {
            for (var i = 0; i < result.entities.length; i++) {
                console.log(result.entities[i]);
            }                    
            // perform additional operations on retrieved records
        },
        function (error) {
            console.log(error.message);
            // handle error conditions
        }
    );

}





function DisplayOdometer(odometervalue, odometerlabel) 
{
    if (odometervalue != null || odometerlabel != null){
        
        container = document.getElementById('statistics');
        container.innerHTML+=' <div class="statistics__wrapper__number d-flex flex-column align-items-center mb-6"><div class="odometer odometer_number_1 odometer-theme-default">1000</div><div class="statistics__text text-center">Years average aircraft age</div></div>';
       // container.innerHTML+=' <div class="statistics__wrapper__number d-flex flex-column align-items-center mb-6"><div class="statistics__number odometer text-center mb-6" id="stat-number-1"><div class="odometer">'+ odometervalue +' </div><div class="statistics__text text-center">'+ odometerlabel +'</div></div>';
       setTimeout(function(){
        $('.odometer_number_1').html(odometervalue);       
    }, 1000);
       
}
}

function Test()
{

    
}
